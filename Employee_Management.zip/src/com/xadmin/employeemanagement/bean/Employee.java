package com.xadmin.employeemanagement.bean;

public class Employee 
{
		private int Id;
		private String FName;
		private String LName;
		private String DOJ;
		private String Department;
		private double Salary;
		private String Experience;
		private String Address;
		private String Education_Details;
		private String Contact_No;
		private String Email_Id;
		private String Active_Status;
		
		public Employee(int Id, String FName, String LName, String DOJ, String Department, double Salary, String experience2,
				String Address, String Education_Details, String Contact_No, String Email_Id, String Active_Status) {
			super();
			this.Id = Id;
			this.FName = FName;
			this.LName = LName;
			this.DOJ = DOJ;
			this.Department = Department;
			this.Salary = Salary;
			this.Experience = experience2;
			this.Address = Address;
			this.Education_Details = Education_Details;
			this.Contact_No = Contact_No;
			this.Email_Id = Email_Id;
			this.Active_Status = Active_Status;
		}
		
		public Employee(String FName, String LName, String DOJ, String Department, double salary2, String Experience, String Address,
				String Education_Details, String Contact_No, String Email_Id, String Active_Status) {
			super();
			this.FName = FName;
			this.LName = LName;
			this.DOJ = DOJ;
			this.Department = Department;
			this.Salary = salary2;
			this.Experience = Experience;
			this.Address = Address;
			this.Education_Details = Education_Details;
			this.Contact_No = Contact_No;
			this.Email_Id = Email_Id;
			this.Active_Status = Active_Status;
		}
		
		public int getId() {
			return Id;
		}
		public void setId(int Id) {
			this.Id = Id;
		}
		public String getFName() {
			return FName;
		}
		public void setFName(String FName) {
			this.FName = FName;
		}
		public String getLName() {
			return LName;
		}
		public void setLName(String LName) {
			this.LName = LName;
		}
		public String getDOJ() {
			return DOJ;
		}
		public void setDOJ(String DOJ) {
			this.DOJ = DOJ;
		}
		public String getDepartment() {
			return Department;
		}
		public void setDepartment(String Department) {
			this.Department = Department;
		}
		public double getSalary() {
			return Salary;
		}
		public void setSalary(double Salary) {
			this.Salary = Salary;
		}
		public String getExperience() {
			return Experience;
		}
		public void setExp(String Experience) {
			this.Experience = Experience;
		}
		public String getAddress() {
			return Address;
		}
		public void setAddress(String Address) {
			this.Address = Address;
		}
		public String getEducation_Details() {
			return Education_Details;
		}
		public void setEducation_Details(String Education_Details) {
			this.Education_Details = Education_Details;
		}
		public String getContact_No() {
			return Contact_No;
		}
		public void setContact_No(String Contact_No) {
			this.Contact_No = Contact_No;
		}
		public String getEmail_Id() {
			return Email_Id;
		}
		public void setEmail_Id(String Email_Id) {
			this.Email_Id = Email_Id;
		}
		public String getActive_Status() {
			return Active_Status;
		}
		public void setActive_Status(String Active_Status) {
			this.Active_Status = Active_Status;
		}
		@Override
		public String toString() {
			return "Employee [Id=" + Id + ", FName=" + FName + ", LName=" + LName + ", DOJ=" + DOJ + ", Department="
					+ Department + ", Salary=" + Salary + ", Experience=" + Experience + ", Address=" + Address
					+ ", Education_Details=" + Education_Details + ", Contact_No=" + Contact_No + ", Email_Id="
					+ Email_Id + ", Active_Status=" + Active_Status + "]";
		}
}
